package kccrs;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.time.LocalTime;

public class MainFX extends Application {

    HashTable table = new HashTable();
    LinkedList complaints = new LinkedList();
    Doublylinkedlist history = new Doublylinkedlist();
    Queue queue = new Queue();
    MinHeap urgent = new MinHeap(100);
    Stack undo = new Stack();

    TableView<Complaint> tableView = new TableView<>();

    @Override
    public void start(Stage stage) {

        Button btnAdd = new Button("Add Complaint");
        Button btnDelete = new Button("Delete Complaint"); 
        Button btnSearch = new Button("Search");
        Button btnDisplay = new Button("Display All");
        Button btnQueue = new Button("Process Queue");
        Button btnUrgent = new Button("Process Urgent");
        Button btnUndo = new Button("Undo");
        Button btnSortSeverity = new Button("Sort Severity");
        Button btnSortTime = new Button("Sort Time");
        Button btnSortArea = new Button("Sort Area");

        
        btnAdd.setOnAction(e -> showAddComplaintWindow());
        btnDelete.setOnAction(e -> showDeleteWindow());
        btnSearch.setOnAction(e -> showSearchWindow());
        btnDisplay.setOnAction(e -> refreshTable());
        btnQueue.setOnAction(e -> processQueue());
        btnUrgent.setOnAction(e -> processUrgent());
        btnUndo.setOnAction(e -> undoAction());
        btnSortSeverity.setOnAction(e -> sort("severity"));
        btnSortTime.setOnAction(e -> sort("time"));
        btnSortArea.setOnAction(e -> sort("area"));

        VBox controlBox = new VBox(10,
                btnAdd,       
                btnDelete,    
                btnSearch,
                btnDisplay,
                btnQueue,
                btnUrgent,
                btnUndo,
                btnSortSeverity,
                btnSortTime,
                btnSortArea
        );
        controlBox.setPadding(new Insets(10));

        BorderPane root = new BorderPane();
        root.setLeft(controlBox);
        root.setCenter(tableView);

        setupTable();

        Scene scene = new Scene(root, 900, 500);
        stage.setTitle("Karachi Complaint System - JavaFX");
        stage.setScene(scene);
        stage.show();
    }

    private void setupTable() {
        TableColumn<Complaint, Integer> c1 = new TableColumn<>("ID");
        c1.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().complaintID).asObject());

        TableColumn<Complaint, String> c2 = new TableColumn<>("Category");
        c2.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().category));

        TableColumn<Complaint, String> c3 = new TableColumn<>("Area");
        c3.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().area));

        TableColumn<Complaint, Integer> c4 = new TableColumn<>("Severity");
        c4.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().severity).asObject());

        TableColumn<Complaint, String> c5 = new TableColumn<>("Time");
        c5.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().timestamp));

        tableView.getColumns().addAll(c1, c2, c3, c4, c5);
    }

    private void showAddComplaintWindow() {
        Stage addStage = new Stage();
        addStage.setTitle("Add Complaint");

        TextField id = new TextField();
        TextField cat = new TextField();
        TextField area = new TextField();
        TextField sev = new TextField();
        TextArea desc = new TextArea();
        Button submit = new Button("Add");

        submit.setOnAction(e -> {
            try {
                int cid = Integer.parseInt(id.getText());
                if (table.isDuplicate(cid)) {
                    showAlert("Duplicate ID!");
                    return;
                }

                Complaint c = new Complaint(
                        cid,
                        cat.getText(),
                        area.getText(),
                        Integer.parseInt(sev.getText()),
                        desc.getText(),
                        LocalTime.now().toString()
                );

                complaints.addComplaint(c);
                table.insert(c);
                queue.enqueue(c);
                urgent.insert(c);
                undo.push(c);

                refreshTable();
                addStage.close();
            } catch (Exception ex) {
                showAlert("Invalid Input!");
            }
        });

        VBox box = new VBox(10,
                new Label("Complaint ID:"), id,
                new Label("Category:"), cat,
                new Label("Area:"), area,
                new Label("Severity (1-3):"), sev,
                new Label("Description:"), desc,
                submit
        );
        box.setPadding(new Insets(10));

        addStage.setScene(new Scene(box, 300, 400));
        addStage.show();
    }
    
    private void showSearchWindow() {
        Stage s = new Stage();
        TextField idField = new TextField();
        Button search = new Button("Search");
        Label result = new Label();

        search.setOnAction(e -> {
            int id = Integer.parseInt(idField.getText());
            Complaint c = table.search(id);
            if (c != null) result.setText(c.toString());
            else result.setText("Not Found");
        });

        VBox box = new VBox(10,
                new Label("Enter ID:"), idField,
                search, result
        );
        box.setPadding(new Insets(10));

        s.setScene(new Scene(box, 250, 200));
        s.show();
    }

    private void processQueue() {
        Complaint c = queue.dequeue();
        if (c == null) showAlert("Queue Empty!");
        else {
            history.add(c);
            showAlert("Processed: " + c);
            refreshTable();
        }
    }

    private void processUrgent() {
        Complaint c = urgent.extractMin();
        if (c == null) showAlert("No urgent complaints.");
        else {
            history.add(c);
            showAlert("Urgent Processed: " + c);
            refreshTable();
        }
    }
    private void undoAction() {
        Complaint c = undo.pop();
        if (c == null) {
            showAlert("Nothing to undo.");
            return;
        }

        table.delete(c.complaintID);
        complaints.remove(c);
        showAlert("Undo successful.");
        refreshTable();
    }

    private void showDeleteWindow() {
        Stage deleteStage = new Stage();
        deleteStage.setTitle("Delete Complaint");

        TextField idField = new TextField();
        Button deleteBtn = new Button("Delete");
        Label result = new Label();

        deleteBtn.setOnAction(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                Complaint c = table.search(id);
                if (c != null) {
                    table.delete(id);
                    complaints.remove(c);
                    showAlert("Complaint deleted: " + c);
                    refreshTable();
                    deleteStage.close();
                } else {
                    result.setText("Complaint not found!");
                }
            } catch (Exception ex) {
                result.setText("Invalid ID!");
            }
        });

        VBox box = new VBox(10,
                new Label("Enter Complaint ID to Delete:"), idField,
                deleteBtn, result
        );
        box.setPadding(new Insets(10));

        deleteStage.setScene(new Scene(box, 300, 200));
        deleteStage.show();
    }

    private void sort(String field) {
        Complaint[] arr = linkedListToArray(complaints);
        SortAlgorithms.mergeSort(arr, 0, arr.length - 1, field);
        tableView.getItems().setAll(arr);
    }

    private Complaint[] linkedListToArray(LinkedList list) {
        LinkedList.Node temp = list.getHead();
        int count = 0;

        while (temp != null) {
            count++;
            temp = temp.next;
        }

        Complaint[] arr = new Complaint[count];
        temp = list.getHead();
        int i = 0;

        while (temp != null) {
            arr[i++] = temp.data;
            temp = temp.next;
        }

        return arr;
    }

    private void refreshTable() {
        tableView.getItems().clear();
        tableView.getItems().addAll(linkedListToArray(complaints));
    }

    private void showAlert(String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setContentText(msg);
        a.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
