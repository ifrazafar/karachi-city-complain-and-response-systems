package kccrs;

public class HashTable {
	private LinkedList[] table;
    private int capacity = 10;

    public HashTable() {
        table = new LinkedList[capacity];
        for (int i = 0; i < capacity; i++)
            table[i] = new LinkedList();
    }
    private int hash(int key) {
        return key % capacity;
    }
    public void insert(Complaint c) {
        int index = hash(c.complaintID);
        table[index].addComplaint(c);
    }
    public Complaint search(int id) {
        int index = hash(id);
        return table[index].search(id);
    }
    public boolean isDuplicate(int id) {
        return search(id) != null;
    }
    public boolean delete(int id) {
        int index = hash(id);
        return table[index].delete(id);
    }
}

