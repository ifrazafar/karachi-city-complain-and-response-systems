package kccrs;

public class LinkedList {
	        class Node {
	        Complaint data;
	        Node next;

	        Node(Complaint data) {
	            this.data = data;
	            this.next = null;
	        }
	    }

	    private Node head;

	    public void addComplaint(Complaint c) {
	        Node newNode = new Node(c);

	        if (head == null) {
	            head = newNode;
	            return;
	        }
	        Node temp = head;
	        while (temp.next != null) temp = temp.next;

	        temp.next = newNode;
	    }

	    public Complaint search(int id) {
	        Node temp = head;

	        while (temp != null) {
	            if (temp.data.complaintID == id)
	                return temp.data;
	            temp = temp.next;
	        }
	        return null;
	    }

	    public boolean delete(int id) {
	        if (head == null) return false;

	        if (head.data.complaintID == id) {
	            head = head.next;
	            return true;
	        }

	        Node temp = head;
	        while (temp.next != null && temp.next.data.complaintID != id)
	            temp = temp.next;

	        if (temp.next == null) return false;

	        temp.next = temp.next.next;
	        return true;
	    }
	    public void remove(Complaint c) { 
	        if (head == null) return;

	        if (head.data == c) {
	            head = head.next;
	            return;
	        }

	        Node temp = head;
	        while (temp.next != null) {
	            if (temp.next.data == c) {
	                temp.next = temp.next.next;
	                return;
	            }
	            temp = temp.next;
	        }
	    }

	    public void display() {
	        Node temp = head;
	        while (temp != null) {
	            System.out.println(temp.data);
	            temp = temp.next;
	        }
	    }

	    public Node getHead() { 
	    	return head; 
	    }
	}


