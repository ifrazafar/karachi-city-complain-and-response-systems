package kccrs;

import java.time.LocalTime;

public class SortAlgorithms {
	public static void insertionSortByTime(Complaint[] arr, int n) {
        for (int i = 1; i < n; i++) {
            Complaint key = arr[i];
            int j = i - 1;

            LocalTime keyTime = LocalTime.parse(key.timestamp);

            while (j >= 0 && LocalTime.parse(arr[j].timestamp).isAfter(keyTime)) {
                arr[j + 1] = arr[j];
                j--;
            }

            arr[j + 1] = key;
        }
    }
	public static void mergeSort(Complaint[] arr, int left, int right, String field) {
        if (left < right) {
            int mid = (left + right) / 2;

            mergeSort(arr, left, mid, field);
            mergeSort(arr, mid + 1, right, field);

            merge(arr, left, mid, right, field);
        }
    }

    private static void merge(Complaint[] arr, int left, int mid, int right, String field) {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        Complaint[] L = new Complaint[n1];
        Complaint[] R = new Complaint[n2];

        for (int i = 0; i < n1; i++) L[i] = arr[left + i];
        for (int j = 0; j < n2; j++) R[j] = arr[mid + 1 + j];

        int i = 0, j = 0, k = left;

        while (i < n1 && j < n2) {
            boolean condition = false;

            switch (field) {

                case "severity":
                    condition = L[i].severity <= R[j].severity;
                    break;

                case "area":
                   
                    condition = L[i].area.compareTo(R[j].area) <= 0;
                    break;
            }

            if (condition) arr[k++] = L[i++];
            else arr[k++] = R[j++];
        }

        while (i < n1) arr[k++] = L[i++];
        while (j < n2) arr[k++] = R[j++];
    }
}

