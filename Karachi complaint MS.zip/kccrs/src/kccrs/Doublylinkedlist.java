package kccrs;

public class Doublylinkedlist {
	class Node {
        Complaint data;
        Node next;
        Node prev;

        Node(Complaint data) { this.data = data; }
    }

    private Node head, tail;

    public void add(Complaint c) {
        Node newNode = new Node(c);
        if (head == null) {
            head = tail = newNode;
            return;
        }
        tail.next = newNode;
        newNode.prev = tail;
        tail = newNode;
    }

    public void displayForward() {
        Node temp = head;
        while (temp != null) {
            System.out.println(temp.data);
            temp = temp.next;
        }
    }
    public void displayBackward() {
        Node temp = tail;
        while (temp != null) {
            System.out.println(temp.data);
            temp = temp.prev;
        }
    }
}

