package kccrs;

public class Stack {
	class Node {
        Complaint data;
        Node next;

        Node(Complaint data) { 
        	this.data = data;
        	}
    }
    private Node top;

    public void push(Complaint c) {
        Node newNode = new Node(c);
        newNode.next = top;
        top = newNode;
    }
    public Complaint pop() {
        if (top == null) 
        	return null;
        Complaint removed = top.data;
        top = top.next;
        return removed;
    }
    public boolean isEmpty() {
        return top == null;
    }
}

