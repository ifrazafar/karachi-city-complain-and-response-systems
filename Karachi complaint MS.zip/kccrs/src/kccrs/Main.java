package kccrs;
import java.util.Scanner;
import java.time.LocalTime;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        HashTable table = new HashTable();
        LinkedList complaintsList = new LinkedList();
        Doublylinkedlist history = new Doublylinkedlist();
        Queue queue = new Queue();
        MinHeap urgent = new MinHeap(100);
        Stack undoStack = new Stack();

        int choice;
        while (true) {
            System.out.println("\n--- Karachi Complaint Management System ---");
            System.out.println("1. Add Complaint");
            System.out.println("2. Process Next (Queue)");
            System.out.println("3. Process Urgent (MinHeap)");
            System.out.println("4. Search Complaint");
            System.out.println("5. Display All Complaints");
            System.out.println("6. Undo Last Action");
            System.out.println("7. Sort by Severity (Merge Sort)");
            System.out.println("8. Sort by Time (Insertion Sort)");
            System.out.println("9. Sort by Area (Merge Sort)");
            System.out.println("10. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {

                case 1:
                    System.out.print("Enter Complaint ID: ");
                    int id = sc.nextInt();
                    sc.nextLine(); 

                    if (table.isDuplicate(id)) {
                        System.out.println("Complaint with this ID already exists!");
                        break;
                    }

                    System.out.print("Enter Category(Water/Electricity/Garbage/Traffic): ");
                    String category = sc.nextLine();

                    System.out.print("Enter Area: ");
                    String area = sc.nextLine();

                    System.out.print("Enter Severity (1=High, 2=Medium, 3=Low): ");
                    int severity = sc.nextInt();
                    sc.nextLine(); 

                    System.out.print("Enter Description: ");
                    String description = sc.nextLine();

                    String timestamp = LocalTime.now().toString();

                    Complaint c = new Complaint(id, category, area, severity, description, timestamp);

                    table.insert(c);
                    complaintsList.addComplaint(c);
                    history.add(c);
                    queue.enqueue(c);
                    urgent.insert(c);
                    undoStack.push(c);

                    System.out.println("Complaint added successfully!");
                    break;

                case 2:
                    Complaint next = queue.dequeue();
                    if (next != null) {
                        System.out.println("Processing next complaint: " + next);
                    } else {
                        System.out.println("No complaints in the queue.");
                    }
                    break;

                case 3: 
                    Complaint urgentComplaint = urgent.extractMin();
                    if (urgentComplaint != null) {
                        System.out.println("Processing urgent complaint: " + urgentComplaint);
                    } else {
                        System.out.println("No urgent complaints.");
                    }
                    break;

                case 4: 
                    System.out.print("Enter Complaint ID to search: ");
                    int searchId = sc.nextInt();
                    sc.nextLine();

                    Complaint found = table.search(searchId);
                    if (found != null) {
                        System.out.println("Found: " + found);
                    } else {
                        System.out.println("Complaint not found!");
                    }
                    break;

                case 5: 
                    System.out.println("All Complaints");
                    complaintsList.display();
                    break;

                case 6: 
                    Complaint lastAction = undoStack.pop();
                    if (lastAction != null) {
                        table.delete(lastAction.complaintID);
                        complaintsList.remove(lastAction);
                        System.out.println("Last action undone: " + lastAction);
                    } else {
                        System.out.println("Nothing to undo!");
                    }
                    break;

                case 7: 
                    Complaint[] severityArr = listToArray(complaintsList);
                    SortAlgorithms.mergeSort(severityArr, 0, severityArr.length - 1, "severity");
                    System.out.println(" Complaints Sorted by Severity");
                    displayArray(severityArr);
                    break;

                case 8: 
                    Complaint[] timeArr = listToArray(complaintsList);
                    SortAlgorithms.insertionSortByTime(timeArr, timeArr.length);
                    System.out.println(" Complaints Sorted by Time ");
                    displayArray(timeArr);
                    break;

                case 9:
                    Complaint[] areaArr = listToArray(complaintsList);
                    SortAlgorithms.mergeSort(areaArr, 0, areaArr.length - 1, "area");
                    System.out.println(" Complaints Sorted by Area ");
                    displayArray(areaArr);
                    break;

                case 10:
                    System.out.println("Exiting System... Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
    private static Complaint[] listToArray(LinkedList list) {
        LinkedList.Node temp = list.getHead();
        int count = 0;
        while (temp != null) {
            count++;
            temp = temp.next;
        }

        Complaint[] arr = new Complaint[count];
        temp = list.getHead();
        for (int i = 0; i < count; i++) {
            arr[i] = temp.data;
            temp = temp.next;
        }
        return arr;
    }

    private static void displayArray(Complaint[] arr) {
        for (Complaint c : arr) {
            System.out.println(c);
        }
    }
}
