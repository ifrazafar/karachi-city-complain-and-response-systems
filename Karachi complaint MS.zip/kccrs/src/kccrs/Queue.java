package kccrs;

public class Queue {
	class Node {
        Complaint data;
        Node next;
        Node(Complaint d) { 
        	this.data = d;
        }
    }
    private Node front, rear;
    public void enqueue(Complaint c) {
        Node newNode = new Node(c);
        if (rear == null) {
            front = rear = newNode;
            return;
        }
        rear.next = newNode;
        rear = newNode;
    }
    public Complaint dequeue() {
        if (front == null) 
        	return null;
        Complaint removed = front.data;
        front = front.next;

        if (front == null) rear = null;
        return removed;
    }
    public boolean isEmpty() {
        return front == null;
    }
}

