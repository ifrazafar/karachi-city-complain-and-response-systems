package kccrs;

public class MinHeap {
	private Complaint[] heap;
    private int size;

    public MinHeap(int capacity) {
        heap = new Complaint[capacity];
        size = 0;
    }

    private int parent(int i) {
    	return (i - 1) / 2; 
    	}
    private int left(int i) { 
    	return 2 * i + 1; 
    	}
    private int right(int i) {
    	return 2 * i + 2;
    	}

    private void swap(int i, int j) {
        Complaint temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }
    public void insert(Complaint c) {
        heap[size] = c;
        int current = size;
        size++;

        while (current != 0 && heap[parent(current)].severity > heap[current].severity) {
            swap(current, parent(current));
            current = parent(current);
        }
    }
    public Complaint extractMin() {
        if (size == 0) return null;

        Complaint root = heap[0];
        heap[0] = heap[size - 1];
        size--;
        heapify(0);

        return root;
    }

    private void heapify(int i) {
        int smallest = i;
        int l = left(i);
        int r = right(i);

        if (l < size && heap[l].severity < heap[smallest].severity) 
        	smallest = l;
        if (r < size && heap[r].severity < heap[smallest].severity) 
        	smallest = r;

        if (smallest != i) {
            swap(i, smallest);
            heapify(smallest);
        }
    }
}

