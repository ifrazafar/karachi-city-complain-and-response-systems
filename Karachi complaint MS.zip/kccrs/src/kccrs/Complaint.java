package kccrs;

public class Complaint {

	    public int complaintID;
	    public String category;
	    public String area;
	    public int severity; 
	    public String description;
	    public String timestamp;

	    public Complaint(int complaintID, String category, String area, int severity, String description, String timestamp) {
	        this.complaintID = complaintID;
	        this.category = category;
	        this.area = area;
	        this.severity = severity;
	        this.description = description;
	        this.timestamp = timestamp;
	    }

	    @Override
	    public String toString() {
	        return "[ID=" + complaintID + ", Category=" + category + ", Area=" + area +
	                ", Severity=" + severity + ", Time=" + timestamp + "]";
	    }
	}


