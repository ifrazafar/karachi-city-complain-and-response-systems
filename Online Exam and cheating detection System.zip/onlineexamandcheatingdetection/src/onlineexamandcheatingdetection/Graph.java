package onlineexamandcheatingdetection;
import java.util.*;

public class Graph {
	 private Map<Student, Integer> interactionCount = new HashMap<>();

	    void addStudent(Student s) {
	        interactionCount.put(s, 0);
	    }
	    void addInteraction(Student s1, Student s2) {
	        interactionCount.put(s1, interactionCount.get(s1) + 1);
	        interactionCount.put(s2, interactionCount.get(s2) + 1);
	    }
	    void detectCheating() {
	        Student suspicious = null;
	        int max = 0;

	        for (Map.Entry<Student, Integer> entry : interactionCount.entrySet()) {
	            if (entry.getValue() > max) {
	                max = entry.getValue();
	                suspicious = entry.getKey();
	            }
	        }
	        if (suspicious != null && max > 0) {
	            System.out.println("Suspicious activity detected for Student ID: " + suspicious.id);
	        } else {
	            System.out.println("No cheating detected.");
	        }
	    }
	}


