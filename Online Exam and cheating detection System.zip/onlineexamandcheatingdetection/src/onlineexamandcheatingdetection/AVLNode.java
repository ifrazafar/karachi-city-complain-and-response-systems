package onlineexamandcheatingdetection;

public class AVLNode {
	 Student student;
	    int score;
	    AVLNode left, right;
	    int height;

	    AVLNode(Student student, int score) {
	        this.student = student;
	        this.score = score;
	        height = 1;
	    }
	}
	class AVLTree {
	    private AVLNode root;

	    public void insert(Student student, int score) {
	        root = insertRec(root, student, score);
	    }

	    private AVLNode insertRec(AVLNode node, Student student, int score) {
	        if (node == null) return new AVLNode(student, score);

	        if (score > node.score) node.left = insertRec(node.left, student, score);
	        else node.right = insertRec(node.right, student, score);

	        node.height = 1 + Math.max(height(node.left), height(node.right));

	        int balance = getBalance(node);

	        if (balance > 1 && score > node.left.score) return rightRotate(node);
	        if (balance > 1 && score <= node.left.score) {
	            node.left = leftRotate(node.left);
	            return rightRotate(node);
	        }

	        if (balance < -1 && score <= node.right.score) return leftRotate(node);
	        if (balance < -1 && score > node.right.score) {
	            node.right = rightRotate(node.right);
	            return leftRotate(node);
	        }

	        return node;
	    }

	    private int height(AVLNode node) { return node == null ? 0 : node.height; }

	    private int getBalance(AVLNode node) { return node == null ? 0 : height(node.left) - height(node.right); }

	    private AVLNode rightRotate(AVLNode y) {
	        AVLNode x = y.left;
	        AVLNode T2 = x.right;
	        x.right = y;
	        y.left = T2;
	        y.height = Math.max(height(y.left), height(y.right)) + 1;
	        x.height = Math.max(height(x.left), height(x.right)) + 1;
	        return x;
	    }

	    private AVLNode leftRotate(AVLNode x) {
	        AVLNode y = x.right;
	        AVLNode T2 = y.left;
	        y.left = x;
	        x.right = T2;
	        x.height = Math.max(height(x.left), height(x.right)) + 1;
	        y.height = Math.max(height(y.left), height(y.right)) + 1;
	        return y;
	    }

	    public void inOrder() { inOrderRec(root); }

	    private void inOrderRec(AVLNode node) {
	        if (node != null) {
	            inOrderRec(node.left);
	            System.out.println(node.student + " - Score: " + node.score);
	            inOrderRec(node.right);
	        }
	    }
	}
	
	
	
	