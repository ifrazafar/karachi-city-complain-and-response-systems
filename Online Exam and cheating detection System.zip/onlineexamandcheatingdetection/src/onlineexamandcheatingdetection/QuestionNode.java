package onlineexamandcheatingdetection;

public class QuestionNode {
	String question;
    int difficulty;
    QuestionNode left, right;

    QuestionNode(String q, int d) {
        question = q;
        difficulty = d;
    }
}
class QuestionTree {
    QuestionNode root;
    public void insert(String q, int d) { root = insertRec(root, q, d); }
    private QuestionNode insertRec(QuestionNode node, String q, int d) {
        if (node == null) return new QuestionNode(q, d);
        if (d < node.difficulty) node.left = insertRec(node.left, q, d);
        else node.right = insertRec(node.right, q, d);
        return node;
    }
    public void inOrder() { inOrderRec(root); }
    private void inOrderRec(QuestionNode node) {
        if (node != null) {
            inOrderRec(node.left);
            System.out.println("Difficulty " + node.difficulty + ": " + node.question);
            inOrderRec(node.right);
        }
    }
}
