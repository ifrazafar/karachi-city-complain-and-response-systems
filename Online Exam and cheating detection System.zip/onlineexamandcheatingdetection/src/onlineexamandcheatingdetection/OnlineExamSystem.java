package onlineexamandcheatingdetection;
import java.util.*;

public class OnlineExamSystem {
	public static void main(String[] args) {

		 Scanner sc = new Scanner(System.in);

		    Map<String, Student> students = new LinkedHashMap<>();
		    Map<String, Exam> exams = new LinkedHashMap<>();

		    System.out.print("Enter number of students: ");
		    int studentCount = sc.nextInt();
		    sc.nextLine();

		    for (int i = 0; i < studentCount; i++) {
		        System.out.print("Enter student ID: ");
		        String id = sc.nextLine();
		        System.out.print("Enter student name: ");
		        String name = sc.nextLine();
		        students.put(id, new Student(id, name));
		    }

		    System.out.print("\nEnter number of exams: ");
		    int examCount = sc.nextInt();
		    sc.nextLine();

		    for (int i = 0; i < examCount; i++) {
		        System.out.print("Enter exam ID: ");
		        String id = sc.nextLine();
		        System.out.print("Enter exam name: ");
		        String name = sc.nextLine();
		        exams.put(id, new Exam(id, name));
		    }

		    System.out.println("\nStudents:");
		    students.values().forEach(System.out::println);

		    System.out.println("\nExams:");
		    exams.values().forEach(System.out::println);

		    AVLTree ranking = new AVLTree();
		    for (Student s : students.values()) {
		        System.out.print("Enter score for " + s.name + ": ");
		        int score = sc.nextInt();
		        sc.nextLine(); 
		        ranking.insert(s, score);
		    }

		    System.out.println("\nStudent Rankings:");
		    ranking.inOrder();

		    System.out.print("\nEnter number of questions: ");
		    int qCount = sc.nextInt();
		    sc.nextLine(); 

		    QuestionTree questions = new QuestionTree();
		    for (int i = 0; i < qCount; i++) {
		        System.out.print("Enter question: ");
		        String q = sc.nextLine();
		        System.out.print("Enter difficulty level: ");
		        int d = sc.nextInt();
		        sc.nextLine(); 
		        questions.insert(q, d);
		    }

		    System.out.println("\nQuestions by Difficulty:");
		    questions.inOrder();

		    Graph interactions = new Graph();
		    for (Student s : students.values()) {
		        interactions.addStudent(s);
		    }

		    System.out.print("\nEnter number of interactions for cheating detection: ");
		    int count = sc.nextInt();
		    sc.nextLine(); 

		    for (int i = 0; i < count; i++) {
		        System.out.print("Enter first student ID: ");
		        String id1 = sc.nextLine();
		        System.out.print("Enter second student ID: ");
		        String id2 = sc.nextLine();
		        interactions.addInteraction(students.get(id1), students.get(id2));
		    }

		    System.out.println("\nCheating Detection:");
		    interactions.detectCheating();

		    sc.close();
		}
}