package onlineexamandcheatingdetection;
public class Exam {
	String id;
    String name;

    public Exam(String id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return name + " (" + id + ")";
    }
}


