package onlineexamandcheatingdetection;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.*;
public class OnlineExamSystemFX extends Application {

    Map<String, Student> students = new LinkedHashMap<>();
    Map<String, Exam> exams = new LinkedHashMap<>();
    AVLTree ranking = new AVLTree();
    QuestionNode questions = new QuestionNode();
    Graph interactions = new Graph();

    TextArea output = new TextArea();

    private void header(String title) {
        output.appendText("\n=================================\n");
        output.appendText(" " + title.toUpperCase() + "\n");
        output.appendText("=================================\n");
    }

    private void line(String msg) {
        output.appendText("➤ " + msg + "\n");
    }

    @Override
    public void start(Stage stage) {

        output.setEditable(false);
        output.setStyle(
                "-fx-font-family: Consolas;" +
                        "-fx-font-size: 13;" +
                        "-fx-control-inner-background: #0f172a;" +
                        "-fx-text-fill: #e5e7eb;"
        );

        TextField sId = new TextField();
        sId.setPromptText("Student ID");

        TextField sName = new TextField();
        sName.setPromptText("Student Name");

        Button addStudent = new Button("Add Student");
        addStudent.setOnAction(e -> {
            if (sId.getText().isEmpty() || sName.getText().isEmpty()) return;

            Student s = new Student(sId.getText(), sName.getText());
            students.put(s.id, s);
            interactions.addStudent(s);

            header("Student Added");
            line("ID   : " + s.id);
            line("Name : " + s.name);

            sId.clear();
            sName.clear();
        });

        TextField eId = new TextField();
        eId.setPromptText("Exam ID");

        TextField eName = new TextField();
        eName.setPromptText("Exam Name");

        Button addExam = new Button("Add Exam");
        addExam.setOnAction(e -> {
            if (eId.getText().isEmpty() || eName.getText().isEmpty()) return;

            exams.put(eId.getText(), new Exam(eId.getText(), eName.getText()));

            header("Exam Added");
            line("Exam ID   : " + eId.getText());
            line("Exam Name : " + eName.getText());

            eId.clear();
            eName.clear();
        });

        TextField scoreId = new TextField();
        scoreId.setPromptText("Student ID");

        TextField score = new TextField();
        score.setPromptText("Score");

        Button addScore = new Button("Add Score");
        addScore.setOnAction(e -> {
            Student s = students.get(scoreId.getText());
            if (s == null || score.getText().isEmpty()) return;

            ranking.insert(s, Integer.parseInt(score.getText()));

            header("Score Added");
            line("Student : " + s.name);
            line("Score   : " + score.getText());

            scoreId.clear();
            score.clear();
        });

        Button showRanking = new Button("Show Ranking");
        showRanking.setOnAction(e -> {
            header("Student Ranking (AVL Tree)");
            ranking.inOrder(output);  
            line("Ranking Generated Successfully");
        });

        TextField qText = new TextField();
        qText.setPromptText("Question");

        TextField diff = new TextField();
        diff.setPromptText("Difficulty");

        Button addQuestion = new Button("Add Question");
        addQuestion.setOnAction(e -> {
            if (qText.getText().isEmpty() || diff.getText().isEmpty()) return;

            questions.insert(qText.getText(), Integer.parseInt(diff.getText()));

            header("Question Added");
            line("Question   : " + qText.getText());
            line("Difficulty : " + diff.getText());

            qText.clear();
            diff.clear();
        });

        Button showQuestions = new Button("Show Questions");
        showQuestions.setOnAction(e -> {
            header("Question Bank (By Difficulty)");
            questions.inOrder(output); 
        });

        TextField c1 = new TextField();
        c1.setPromptText("Student ID 1");

        TextField c2 = new TextField();
        c2.setPromptText("Student ID 2");

        Button addInteraction = new Button("Add Interaction");
        addInteraction.setOnAction(e -> {
            Student s1 = students.get(c1.getText());
            Student s2 = students.get(c2.getText());
            if (s1 == null || s2 == null) return;

            interactions.addInteraction(s1, s2);

            header("Interaction Added");
            line(c1.getText() + " ↔ " + c2.getText());

            c1.clear();
            c2.clear();
        });

        Button detect = new Button("Detect Cheating");
        detect.setOnAction(e -> {
            header("Cheating Detection Report");
            interactions.detectCheating(output);
            line("Review suspicious links carefully");
        });

        VBox leftContent = new VBox(6,
                new Label("Students"),
                sId, sName, addStudent,
                new Separator(),

                new Label("Exams"),
                eId, eName, addExam,
                new Separator(),

                new Label("Scores"),
                scoreId, score, addScore, showRanking,
                new Separator(),

                new Label("Questions"),
                qText, diff, addQuestion, showQuestions,
                new Separator(),

                new Label("Cheating Detection"),
                c1, c2, addInteraction, detect
        );
        leftContent.setPadding(new Insets(8));
        leftContent.setPrefWidth(220);

        ScrollPane leftPanel = new ScrollPane(leftContent);
        leftPanel.setFitToWidth(true);
        leftPanel.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        leftPanel.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        VBox rightPanel = new VBox(5,
                new Label("System Output"),
                output
        );
        rightPanel.setPadding(new Insets(10));
        VBox.setVgrow(output, Priority.ALWAYS);

        HBox root = new HBox(8, leftPanel, rightPanel);
        root.setPadding(new Insets(8));

        stage.setScene(new Scene(root, 750, 480)); 
        stage.setTitle("Online Exam System - JavaFX (Horizontal)");
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    static class Student {
        String id, name;
        public Student(String id, String name) { this.id = id; this.name = name; }
    }

    static class Exam {
        String id, name;
        public Exam(String id, String name) { this.id = id; this.name = name; }
    }

    static class AVLTree {
        private static class Node {
            Student s; int score; Node left, right;
            Node(Student s, int score) { this.s = s; this.score = score; }
        }
        private Node root;
        public void insert(Student s, int score) {
            root = insertRec(root, s, score);
        }
        private Node insertRec(Node node, Student s, int score) {
            if (node == null) return new Node(s, score);
            if (score < node.score) node.left = insertRec(node.left, s, score);
            else node.right = insertRec(node.right, s, score);
            return node;
        }
        public void inOrder(TextArea output) { inOrderRec(root, output); }
        private void inOrderRec(Node node, TextArea output) {
            if (node != null) {
                inOrderRec(node.right, output);
                output.appendText(node.s.name + " : " + node.score + "\n");
                inOrderRec(node.left, output);
            }
        }
    }

    static class QuestionNode {
        static class QNode {
            String text; int difficulty; QNode left, right;
            QNode(String t, int d) { text=t; difficulty=d; }
        }
        private QNode root;
        public void insert(String text, int difficulty) {
            root = insertRec(root, text, difficulty);
        }
        private QNode insertRec(QNode node, String text, int d) {
            if (node==null) return new QNode(text,d);
            if (d<node.difficulty) node.left = insertRec(node.left,text,d);
            else node.right = insertRec(node.right,text,d);
            return node;
        }
        public void inOrder(TextArea output) { inOrderRec(root, output); }
        private void inOrderRec(QNode node, TextArea output) {
            if (node!=null) {
                inOrderRec(node.left, output);
                output.appendText(node.text + " (Difficulty: "+node.difficulty+")\n");
                inOrderRec(node.right, output);
            }
        }
    }
    static class Graph {
        Map<String, List<String>> adj = new HashMap<>();

        public void addStudent(Student s) {
            adj.putIfAbsent(s.id, new ArrayList<>());
        }

        public void addInteraction(Student a, Student b) {
            adj.get(a.id).add(b.id);
            adj.get(b.id).add(a.id);
        }

        public void detectCheating(TextArea output) {

            for (Map.Entry<String, List<String>> entry : adj.entrySet()) {

                String studentId = entry.getKey();
                List<String> interactions = entry.getValue();

                if (!interactions.isEmpty()) {
                    output.appendText(
                        "Suspicious activity detected for Student ID: "
                        + studentId + "\n"
                    );
                    return;
                }
            }

            output.appendText("No suspicious activity detected\n");
        }
    }

}
    

        	    
         
